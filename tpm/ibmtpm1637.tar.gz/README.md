# ibmswtpm2
This project is an implementation of the TCG TPM 2.0 specification. It is based on the TPM specification Parts 3 and 4 source code donated by Microsoft, with additional files to complete the implementation.

See the companion IBM TSS at https://sourceforge.net/projects/ibmtpm20tss/
